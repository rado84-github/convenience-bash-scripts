#!/usr/bin/bash

sort -r "$1".txt > sorted-"$1".txt
