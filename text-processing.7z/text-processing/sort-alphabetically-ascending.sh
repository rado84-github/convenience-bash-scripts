#!/usr/bin/bash

sort -i "$1".txt > sorted-"$1".txt
