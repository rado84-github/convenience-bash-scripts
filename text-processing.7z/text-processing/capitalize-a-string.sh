#!/usr/bin/bash

string="$1"
echo "${string^^}"
