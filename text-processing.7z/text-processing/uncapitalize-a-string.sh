#!/usr/bin/env bash

string="$1"
echo "${string,}"
