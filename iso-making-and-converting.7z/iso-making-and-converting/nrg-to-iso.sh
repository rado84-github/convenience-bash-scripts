nrg2iso "$1".nrg "$1".iso
