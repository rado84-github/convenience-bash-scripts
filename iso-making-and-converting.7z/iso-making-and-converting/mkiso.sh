#!/usr/bin/env bash
mkisofs -o "$1".iso "$1"/
