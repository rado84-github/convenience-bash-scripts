bchunk -v "$1".bin "$1".cue "$1"
