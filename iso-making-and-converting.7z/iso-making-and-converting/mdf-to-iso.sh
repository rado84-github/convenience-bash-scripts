mdf2iso "$1".mdf "$1".iso
