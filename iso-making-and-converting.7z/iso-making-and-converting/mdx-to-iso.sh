#!/usr/bin/bash

mdx2iso $1.mdx $1.iso
