ccd2iso "$1".img "$1".iso
