#!/usr/bin/bash

7z x -y "$1".zst -o"$1/" -mmt=20;
