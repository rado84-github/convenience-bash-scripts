#!/usr/bin/bash

7z x -y "$1".rar -o"$1/" -mmt=20;
