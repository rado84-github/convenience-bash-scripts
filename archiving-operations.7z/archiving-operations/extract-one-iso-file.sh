#!/usr/bin/bash

7z x -y "$1".iso -o"$1/" -mmt=20;
