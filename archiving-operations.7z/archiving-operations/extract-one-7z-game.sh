#!/usr/bin/bash

7z x -y "$1".7z -o"/B/GAMES" -mmt=20;
