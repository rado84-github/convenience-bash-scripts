#!/usr/bin/bash

7z a "$1.7z" "$1" -mx=0 -mmt=20
