#!/usr/bin/bash

7z x -y "$1".zip -o"$1/" -mmt=20;
