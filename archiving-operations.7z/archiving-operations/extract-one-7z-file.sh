#!/usr/bin/bash

7z x -y "$1".7z -o"$1/" -mmt=20;
