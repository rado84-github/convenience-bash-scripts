#!/usr/bin/bash

7z x -y "$1".exe -o"$1/" -mmt=20;
